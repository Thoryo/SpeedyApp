package com.example.speedyapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Re50hhihwobActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_re50hhihwob)
    }
}