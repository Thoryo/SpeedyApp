package com.example.speedyapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Rb41hbahActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_rb41hbah)
    }
}